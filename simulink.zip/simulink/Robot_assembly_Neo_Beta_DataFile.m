% Simscape(TM) Multibody(TM) version: 24.2

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(5).translation = [0.0 0.0 0.0];
smiData.RigidTransform(5).angle = 0.0;
smiData.RigidTransform(5).axis = [0.0 0.0 0.0];
smiData.RigidTransform(5).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [-3.2363681575359397e-13 86.500000000000043 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931935;  % rad
smiData.RigidTransform(1).axis = [-0.57735026918962518 -0.57735026918962695 -0.57735026918962518];
smiData.RigidTransform(1).ID = "B[Base_Chassis_Neo-2:-:Right_Wheel_assembly_Neo-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [-108.12856780324745 -32.071731649358526 47.595311393138275];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931939;  % rad
smiData.RigidTransform(2).axis = [-0.57735026918962518 -0.57735026918962296 -0.57735026918962917];
smiData.RigidTransform(2).ID = "F[Base_Chassis_Neo-2:-:Right_Wheel_assembly_Neo-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [2.9343194540842892e-13 -86.5 0];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931975;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962651 -0.5773502691896244 0.57735026918962651];
smiData.RigidTransform(3).ID = "B[Base_Chassis_Neo-2:-:Left_Wheel_Assembly_Neo-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-108.12856780324675 59.928268350641268 47.595311393139689];  % mm
smiData.RigidTransform(4).angle = 2.0943951023931975;  % rad
smiData.RigidTransform(4).axis = [0.57735026918962651 -0.57735026918962851 0.5773502691896224];
smiData.RigidTransform(4).ID = "F[Base_Chassis_Neo-2:-:Left_Wheel_Assembly_Neo-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [0 0 0];  % mm
smiData.RigidTransform(5).angle = 0;  % rad
smiData.RigidTransform(5).axis = [0 0 0];
smiData.RigidTransform(5).ID = "RootGround[Base_Chassis_Neo-2]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(3).mass = 0.0;
smiData.Solid(3).CoM = [0.0 0.0 0.0];
smiData.Solid(3).MoI = [0.0 0.0 0.0];
smiData.Solid(3).PoI = [0.0 0.0 0.0];
smiData.Solid(3).color = [0.0 0.0 0.0];
smiData.Solid(3).opacity = 0.0;
smiData.Solid(3).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.059999999999999998;  % kg
smiData.Solid(1).CoM = [-108.0386490565178 9.313096829247149 47.581555835155484];  % mm
smiData.Solid(1).MoI = [89.025315548052419 155.17382388267401 88.638954896171654];  % kg*mm^2
smiData.Solid(1).PoI = [0.00055733622596032388 -0.057201403012638756 -0.010399617923702436];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "Right_Wheel_assembly_Neo*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.059999999999999998;  % kg
smiData.Solid(2).CoM = [-108.03864906223374 18.550928464542448 47.581555816456373];  % mm
smiData.Solid(2).MoI = [89.020157719317552 155.17382388271193 88.633797068073861];  % kg*mm^2
smiData.Solid(2).PoI = [-0.0070235463553689889 -0.057201403518373377 0.045338687583252789];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "Left_Wheel_Assembly_Neo*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 2.3799999999999999;  % kg
smiData.Solid(3).CoM = [-3.0610153871814667 0.98097161255048704 125.84312293205568];  % mm
smiData.Solid(3).MoI = [25341.09179899393 20868.764226915657 10357.869137904119];  % kg*mm^2
smiData.Solid(3).PoI = [70.488187942266748 -104.94071233544574 -457.37147762850185];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "Base_Chassis_Neo*:*Default";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(2).Rz.Pos = 0.0;
smiData.RevoluteJoint(2).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -135.54662954122921;  % deg
smiData.RevoluteJoint(1).ID = "[Base_Chassis_Neo-2:-:Right_Wheel_assembly_Neo-2]";

smiData.RevoluteJoint(2).Rz.Pos = -45.299883370432767;  % deg
smiData.RevoluteJoint(2).ID = "[Base_Chassis_Neo-2:-:Left_Wheel_Assembly_Neo-2]";

