
clear; clc; close all;

% --- 1. Physical Parameters (From Finalized Parameters) ---
m_w = 0.06;          % Wheel mass (kg) 
I_w = 0.000155;       % Wheel inertia (kg.m^2) 
m_c = 2.529;              % Chassis mass (kg) 
r   = 0.045;            % Wheel radius (m) 
L   = 0.11842;          % CG height (m) 
J_th = 0.020868;      % Pitch inertia (kg.m^2) 
J_yw = 0.012975;      % Yaw inertia (kg.m^2) 
D   = 0.265;            % Lateral wheel separation (m) 
g   = 9.81;             % Gravity (m/s^2) 


% --- 2. Derived Coupling Constants ---
% These capture the exact interaction between falling and rolling
alpha = m_c + 2*m_w + 2*(I_w / r^2);   % Effective Linear Mass
beta  = m_c * L;                       % Mass-Moment Coupling
gamma = J_th + m_c * L^2;              % Effective Pitch Inertia
delta = alpha * gamma - beta^2;        % System Determinant (Exact)

% Yaw effective inertia
J_yaw_star = J_yw + (D^2 / 2) * (m_w + I_w / r^2);

% --- 3. Exact State Space Matrices (6x6) ---
% State Vector x = [x; v; theta; omega; delta; d_delta]

% Matrix A: System Dynamics
A = zeros(6,6);
A(1,2) = 1; % dx = v
A(3,4) = 1; % dtheta = omega
A(5,6) = 1; % ddelta = d_delta

% Dynamic Terms (Coupled)
A(2,3) = -(beta^2 * g) / delta;         % Linear accel caused by leaning (Reaction force)
A(4,3) = (alpha * m_c * g * L) / delta; % Angular accel caused by gravity (Instability)

% Matrix B: Input Map (6x2)
B = zeros(6,2);

% Linear Authority (Symmetric)
B_lin = (gamma/r + beta) / delta; 
B(2,1) = B_lin; B(2,2) = B_lin;

% Angular Authority (Symmetric, Negative)
% Note: Positive motor torque pitches chassis BACKWARD (-theta)
B_ang = -(alpha + beta/r) / delta; 
B(4,1) = B_ang; B(4,2) = B_ang;

% Yaw Authority (Anti-Symmetric)
B_yaw = D / (2 * r * J_yaw_star);
B(6,1) = B_yaw; B(6,2) = -B_yaw;

% Output Matrix C (Full State Feedback)
C = eye(6); 
D_mat = zeros(6,2);

disp('Exact A Matrix:'); disp(A);
disp('Exact B Matrix:'); disp(B);
Cont = ctrb(A,B);

% --- 4. Controller Design (Pole Placement) ---
% Using the same poles from your previous code for comparison
p = [-2, -3, -4, -5, -8, -10]; %[cite: 592]

% Check Controllability
if rank(ctrb(A,B)) == 6
    disp('System is Controllable. Calculating Gains...');
    K = place(A, B, p);
    disp('State Feedback Gain Matrix K:');
    disp(K);
else
    error('System is NOT controllable!');
end

% --- 5. Closed Loop Simulation ---
% Create Closed Loop System: dx = (A - B*K)x
A_cl = A - B*K;

% Define inputs for Step Response (Move forward)
% Applying equal torque step to both wheels
B_step_both = sum(B, 2); % Sums columns 1 and 2 effectively

sys_cl = ss(A_cl, B_step_both, C, zeros(6,1));

% Simulation Params
t = linspace(0, 5, 500); % [cite: 608]
[y, t_out] = step(sys_cl, t);

% --- 6. Plotting ---
figure('Name', 'Exact Model Step Response');
labels = {'x (pos)', 'v (vel)', '\theta (pitch)', '\omega (pitch rate)', '\delta (yaw)', 'd\delta (yaw rate)'};
hold on;
for i = 1:6
    plot(t_out, y(:,i), 'LineWidth', 1.5);
end
grid on;
legend(labels);
title('Closed-Loop Response: Exact Model (Input: Unit Step Torque)');
xlabel('Time (s)');
ylabel('Amplitude');
ylim([-10 10]); % Zoom in to see stabilization

% --- 7. Plotting ---
figure('Name', 'Closed-Loop Response (Exact Model)');
linewidth = 1.5;

subplot(3,1,1);
plot(t_out, y(:,1), 'LineWidth', linewidth); hold on;
plot(t_out, y(:,2), '--', 'LineWidth', linewidth);
title('Linear Motion');
legend('Position (x)', 'Velocity (v)');
grid on; ylabel('Metric');

subplot(3,1,2);
plot(t_out, y(:,3), 'LineWidth', linewidth); hold on;
plot(t_out, y(:,4), '--', 'LineWidth', linewidth);
title('Pitch Dynamics (Balance)');
legend('Pitch Angle (\theta)', 'Pitch Rate (\omega)');
grid on; ylabel('Rad / Rad/s');

subplot(3,1,3);
plot(t_out, y(:,5), 'LineWidth', linewidth); hold on;
plot(t_out, y(:,6), '--', 'LineWidth', linewidth);
title('Yaw Dynamics');
legend('Yaw Angle (\delta)', 'Yaw Rate');
grid on; ylabel('Rad / Rad/s');
xlabel('Time (s)');

% Check Eigenvalues to verify stability
eig_cl = eig(A_cl);
disp('Closed Loop Poles:');
disp(eig_cl);

[U,Si,V] = svd(Cont,"econ"); %% resulted in the revelation that the pitch rate is the most controllable state,
                              % and the linear velocity is the least controllable.

%% --- FREQUENCY RESPONSE ANALYSIS (Symmetric SISO Projection) ---

% 1. Combine Inputs (B) and Average Gains (K) to force SISO
% We assume the robot acts like a single unit for pitch balancing.
B_siso = B(:,1) + B(:,2);           % Total torque influence
K_siso = (K(1,:) + K(2,:)) / 2;     % Average gain to smooth out asymmetry

% 2. Open-Loop System (For Stability Margins)
% Loop Gain L(s) = K_siso * (sI - A)^-1 * B_siso
sys_loop = ss(A, B_siso, K_siso, 0);

% 3. Closed-Loop System (For Bandwidth)
% We close the loop manually: A_cl = A - B*K
A_cl = A - B_siso * K_siso;
C_pitch = zeros(1, 6); 
C_pitch(3) = 1; % Observe Pitch Angle only
sys_cl_siso = ss(A_cl, B_siso, C_pitch, 0);

%% --- PLOT GENERATION ---

% FIGURE 1: Stability Analysis (Open Loop)
figure('Name', 'bode');


margin(sys_loop); 
grid on;
title('1. Stability Margins (Bode Plot)');


figure('Name','nyquist')
nyquist(sys_loop);
grid on;
title('2. Nyquist Stability Criterion');
axis([-20 20 -20 20]); 


% FIGURE 2: Performance Analysis (Closed Loop)
figure('Name', 'Closed Loop Performance');

% Plot 3: Bandwidth
bode(sys_cl_siso);
grid on;
title('3. Closed Loop Bandwidth');
% This shows the speed of response.

% --- 7. Performance Metrics Calculation ---

% Ensure the target reference values (for a step disturbance, we measure against the final settled value)
target_x = y(end, 1);
target_theta = y(end, 3);

% Calculate step response characteristics using MATLAB's stepinfo
info_x = stepinfo(y(:,1), t_out, target_x);
info_theta = stepinfo(y(:,3), t_out, target_theta);

% Calculate absolute steady-state errors (assuming ideal target is 0 for a regulator)

ss_error_x = abs(y(end,1)); 
ss_error_theta = abs(y(end,3));

% Display Results in the Command Window
disp('=========================================');
disp('      LQR PERFORMANCE METRICS            ');
disp('=========================================');

disp('--- Linear Position (x) ---');
fprintf('Rise Time:          %.4f s\n', info_x.RiseTime);
fprintf('Settling Time (2%%): %.4f s\n', info_x.SettlingTime);
fprintf('Steady-State Error: %.4f m\n\n', ss_error_x);

disp('--- Pitch Angle (\theta) ---');
fprintf('Rise Time:          %.4f s\n', info_theta.RiseTime);
fprintf('Settling Time (2%%): %.4f s\n', info_theta.SettlingTime);
fprintf('Steady-State Error: %.4f rad (%.4f deg)\n', ss_error_theta, rad2deg(ss_error_theta));
disp('=========================================');