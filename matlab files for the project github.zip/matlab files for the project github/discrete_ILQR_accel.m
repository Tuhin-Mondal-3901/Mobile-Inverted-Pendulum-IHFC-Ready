% =========================================================================
% Tuhin Mondal |/ LQR Control Analysis
% Two-Wheeled Balancing Robot (Lagrangian Acceleration-Input Model)
% =========================================================================
clear; clc; close all;

%% 1. PHYSICAL PARAMETERS (Extracted & Corrected from Old Code)
% Note: Stepper kinematics allow us to ignore wheel mass (m_w) and yaw 
% inertia (I_z), as linear and yaw accelerations are directly commanded.

m_B = 1.735;      % Chassis mass (kg)
l   = 0.11842;    % Distance from axle to CoG (m)
I_y = 0.020868;   % Pitch moment of inertia (kg.m^2)
g   = 9.81;       % Acceleration due to gravity (m/s^2)

%% 2. STATE-SPACE MATRICES (From Eq. 16 of Lagrangian Derivation)
% State Vector: X = [x, dx, theta, dtheta, psi, dpsi]'
% Input Vector: U = [ddx, ddpsi]' (Linear Accel, Yaw Accel)

% Grouped terms for pitch dynamics
den = I_y + m_B * l^2; 
a_43 = (m_B * g * l) / den;
b_41 = -(m_B * l) / den;

% Construct Continuous-Time Matrices
A = [0, 1, 0,    0, 0, 0,0;
     0, 0, 0,    0, 0, 0,0;
     0, 0, 0,    1, 0, 0,0;
     0, 0, a_43, 0, 0, 0,0;
     0, 0, 0,    0, 0, 1,0;
     0, 0, 0,    0, 0, 0,0;
     1,0,0,0,0,0,0];

B = [0,    0;
     1,    0;
     0,    0;
     b_41, 0;
     0,    0;
     0,    1;
     0,0];



% Assuming full-state estimation (IMU + Odometry)
C = eye(7);
D = zeros(7,2);
Ts = 0.01;
sys_ol = ss(A, B, C, D);
sys_ol.StateName = {'x', 'v', 'theta', 'omega', 'psi', 'psi_rate','x_int'};
sys_ol.InputName = {'Linear_Accel', 'Yaw_Accel'};
sys_ol.OutputName = sys_ol.StateName;
sys_d = c2d(sys_ol,Ts,'zoh');
fprintf('======================================================\n');
fprintf('                PLANT MODELLING\n');
fprintf('======================================================\n');
disp('Continuous-Time System Matrix (A):'); disp(A);
disp('Continuous-Time Input Matrix (B):'); disp(B);

%% 3. OPEN-LOOP ANALYSIS
fprintf('\n======================================================\n');
fprintf('                OPEN-LOOP ANALYSIS\n');
fprintf('======================================================\n');

% Poles (Eigenvalues)
P_ol = eig(A);
disp('Open-Loop Poles:'); disp(P_ol);
if any(real(P_ol) > 0)
    fprintf('--> CONCLUSION: System is Open-Loop UNSTABLE (RHP Pole at +%.2f)\n', max(real(P_ol)));
end

% Controllability
Co = ctrb(A, B);
rank_Co = rank(Co);
fprintf('\nControllability Matrix Rank: %d / 6\n', rank_Co);
if rank_Co == 7
    fprintf('--> CONCLUSION: System is Fully Controllable.\n');
else
    error('System is NOT controllable. Check mathematical derivation.');
end



%% 5. LQR CONTROLLER DESIGN (Bryson's Rule)
fprintf('\n======================================================\n');
fprintf('                CONTROLLER SYNTHESIS\n');
fprintf('======================================================\n');

% Maximum Acceptable Deviations (Tuning Parameters)
max_x      = 0.5;           % m      (Tight position control)
max_v      = 0.5;           % m/s
max_theta  = deg2rad(5);    % rad    (~5 degrees max lean)
max_omega  = deg2rad(20);   % rad/s 
max_psi    = deg2rad(10);   % rad    (~10 degrees yaw drift)
max_dpsi   = deg2rad(50);   % rad/s
max_x_int = 1.0; %m.s
% Maximum Acceptable Inputs (Accelerations)
max_u_lin  = 5.0;           % m/s^2  (Stepper linear accel limit)
max_u_yaw  = 10.0;          % rad/s^2 (Stepper yaw accel limit)

% State Weighting Matrix (Q)
Q = diag([1/max_x^2, 1/max_v^2, 1/max_theta^2, ...
          1/max_omega^2, 1/max_psi^2, 1/max_dpsi^2,1/max_x_int^2]);

% Input Weighting Matrix (R)
R = diag([1/max_u_lin^2, 1/max_u_yaw^2]);

% Compute Optimal Gain Matrix
K = lqr(A, B, Q, R);
disp('Optimal State-Feedback Gain Matrix (K):');
disp(K);
K_d = dlqr(sys_d.A,sys_d.B,Q,R);
disp(K_d)

%eig(A-B*K)
%eig(sys_d.A - sys_d.B*K_d)

% 1. Convert the Discrete State-Space to a Transfer Function
%G_d = tf(sys_d);

% 2. Isolate the Pitch Dynamics
% G_d(Output, Input) -> We want Output 3 (theta) from Input 1 (Linear_Accel)
%G_theta_d = G_d(3, 1);

% 3. Launch the PID Tuner App
%pidTuner(G_theta_d, 'PID')

%% Discrete cascade PID design (Ts = 0.01)

% ---- Extract discrete SISO TFs ----

% Pitch channel (input 1 = ddx, output 3 = theta)
C_th  = zeros(1,7); C_th(3)  = 1;
C_x   = zeros(1,7); C_x(1)   = 1;
C_psi = zeros(1,7); C_psi(5) = 1;

[Ad, Bd, Cd, Dd] = ssdata(sys_d);

sys_d_th  = ss(Ad, Bd(:,1), C_th,  0, Ts);
sys_d_x   = ss(Ad, Bd(:,1), C_x,   0, Ts);
sys_d_psi = ss(Ad, Bd(:,2), C_psi, 0, Ts);

tf_d_th  = tf(sys_d_th)
tf_d_x   = tf(sys_d_x)
tf_d_psi = tf(sys_d_psi)

%% ---- Inner pitch PD (discrete pole placement) ----
% Continuous target poles at -30 rad/s
% Map to discrete: z = exp(s*Ts)
p_inner = exp(-30 * Ts);
fprintf('Target discrete inner poles: z = %.4f\n', p_inner);

% Desired discrete characteristic polynomial
% (z - p_inner)^2 = z^2 - 2*p_inner*z + p_inner^2
p1 = p_inner;
p2 = p_inner;
desired_inner = conv([1, -p1], [1, -p2]);
fprintf('Desired inner poly: z^2 + %.4fz + %.4f\n', ...
        desired_inner(2), desired_inner(3));

%% ---- Outer position P (discrete) ----
% Continuous target poles at -3 rad/s
p_outer = exp(-3 * Ts);
fprintf('\nTarget discrete outer pole: z = %.4f\n', p_outer);

%% ---- Yaw PD (discrete) ----
% Continuous target poles at -10 rad/s  
p_yaw = exp(-10 * Ts);
fprintf('Target discrete yaw poles: z = %.4f\n', p_yaw);

%% ---- Design discrete PID using MATLAB pidtune ----
% Inner pitch loop
C_pitch_d = pidtune(sys_d_th, 'PD', 30)

% Outer position loop  
% First close inner loop
sys_inner_cl = feedback(C_pitch_d * sys_d_th, 1);
sys_pos_ol   = sys_d_x * sys_inner_cl;
C_pos_d      = pidtune(sys_pos_ol, 'P', 3)

% Yaw loop (independent)
C_yaw_d = pidtune(sys_d_psi, 'PD', 10)

%% ---- Verify all loops ----
sys_pitch_cl = feedback(C_pitch_d * sys_d_th, 1);
sys_yaw_cl   = feedback(C_yaw_d   * sys_d_psi, 1);

fprintf('\nPitch closed loop poles:\n');
disp(pole(sys_pitch_cl))

fprintf('Yaw closed loop poles:\n');
disp(pole(sys_yaw_cl))

figure(1); step(sys_pitch_cl, 1);  title('Discrete Pitch Loop');
figure(2); step(sys_yaw_cl,   2);  title('Discrete Yaw Loop');

% Close all loops and check poles
sys_pitch_cl = feedback(C_pitch_d * sys_d_th, 1);
sys_yaw_cl   = feedback(C_yaw_d   * sys_d_psi, 1);

% Outer position loop around closed inner pitch loop
sys_pos_plant = sys_d_x * sys_pitch_cl;
sys_pos_cl    = feedback(C_pos_d * sys_pos_plant, 1);

fprintf('=== PITCH CL POLES ===\n');
disp(pole(sys_pitch_cl))

fprintf('=== YAW CL POLES ===\n');
disp(pole(sys_yaw_cl))

fprintf('=== POSITION CL POLES ===\n');
disp(pole(sys_pos_cl))

% Step responses
figure(1); step(sys_pitch_cl, 1);   title('Pitch Closed Loop');
figure(2); step(sys_yaw_cl,   2);   title('Yaw Closed Loop');
figure(3); step(sys_pos_cl,   5);   title('Position Closed Loop');