% =========================================================================
% Tuhin Mondal |LQR Control Analysis
% Two-Wheeled Balancing Robot (Lagrangian Acceleration-Input Model)
% =========================================================================
clear; clc; close all;

%% 1. PHYSICAL PARAMETERS (Extracted & Corrected from Old Code)
% Note: Stepper kinematics allow us to ignore wheel mass (m_w) and yaw 
% inertia (I_z), as linear and yaw accelerations are directly commanded.

m_B = 1.735;      % Chassis mass (kg)
l   = 0.11842;    % Distance from axle to CoG (m)
I_y = 0.020868;   % Pitch moment of inertia (kg.m^2)
g   = 9.81;       % Acceleration due to gravity (m/s^2)

%% 2. STATE-SPACE MATRICES (From Eq. 16 of Lagrangian Derivation)
% State Vector: X = [x, dx, theta, dtheta, psi, dpsi]'
% Input Vector: U = [ddx, ddpsi]' (Linear Accel, Yaw Accel)

% Grouped terms for pitch dynamics
den = I_y + m_B * l^2; 
a_43 = (m_B * g * l) / den; 
b_41 = -(m_B * l) / den;

% Construct Continuous-Time Matrices
A = [0, 1, 0,    0, 0, 0,0;
     0, 0, 0,    0, 0, 0,0;
     0, 0, 0,    1, 0, 0,0;
     0, 0, a_43, 0, 0, 0,0;
     0, 0, 0,    0, 0, 1,0;
     0, 0, 0,    0, 0, 0,0;
     1,0,0,0,0,0,0];

B = [0,    0;
     1,    0;
     0,    0;
     b_41, 0;
     0,    0;
     0,    1;
     0,0];

% Assuming full-state estimation (IMU + Odometry)
C = eye(7);
D = zeros(7,2);

sys_ol = ss(A, B, C, D);
sys_ol.StateName = {'x', 'v', 'theta', 'omega', 'psi', 'psi_rate','x_int'};
sys_ol.InputName = {'Linear_Accel', 'Yaw_Accel'};
sys_ol.OutputName = sys_ol.StateName; % <-- Added to fix the indexing error

fprintf('======================================================\n');
fprintf('                PLANT MODELLING\n');
fprintf('======================================================\n');
disp('Continuous-Time System Matrix (A):'); disp(A);
disp('Continuous-Time Input Matrix (B):'); disp(B);

%% 3. OPEN-LOOP ANALYSIS
fprintf('\n======================================================\n');
fprintf('                OPEN-LOOP ANALYSIS\n');
fprintf('======================================================\n');

% Poles (Eigenvalues)
P_ol = eig(A);
disp('Open-Loop Poles:'); disp(P_ol);
if any(real(P_ol) > 0)
    fprintf('--> CONCLUSION: System is Open-Loop UNSTABLE (RHP Pole at +%.2f)\n', max(real(P_ol)));
end

% Controllability
Co = ctrb(A, B);
rank_Co = rank(Co);
fprintf('\nControllability Matrix Rank: %d / 6\n', rank_Co);
if rank_Co == 7
    fprintf('--> CONCLUSION: System is Fully Controllable.\n');
else
    error('System is NOT controllable. Check mathematical derivation.');
end

% We isolate the primary unstable channel: Linear Accel (u1) -> Pitch (x3)
sys_pitch = sys_ol('theta', 'Linear_Accel');

% Plot 1: Bode Plot
fig1 = figure('Name', 'Open-Loop Frequency Response', 'Position', [100, 100, 800, 600]);
bode(sys_pitch);
grid on;
set(findall(gcf,'type','line'),'linewidth',1.5);
title('Bode Diagram: Linear Acceleration to Pitch Angle', 'FontSize', 14, 'FontWeight', 'bold');
% Note: Use 'exportgraphics(fig1, 'bode_plot.eps')' to save for Overleaf.

% Plot 2: Nyquist Plot
fig2 = figure('Name', 'Nyquist Stability', 'Position', [150, 150, 800, 600]);
nyquist(sys_pitch);
grid on;
set(findall(gcf,'type','line'),'linewidth',2); % Thickened to 2 for visibility
title('Nyquist Diagram: Linear Acceleration to Pitch Angle', 'FontSize', 14, 'FontWeight', 'bold');

% Tightly frame the critical point (-1,0) and the plant's response (0 to 0.102)
axis([-1.2 0.3 -0.5 0.5]);

%% 5. LQR CONTROLLER DESIGN (Bryson's Rule)
fprintf('\n======================================================\n');
fprintf('                CONTROLLER SYNTHESIS\n');
fprintf('======================================================\n');

% Maximum Acceptable Deviations (Tuning Parameters)
max_x      = 2.0;           % m      (Tight position control)
max_v      = 1.5;           % m/s
max_theta  = deg2rad(5);    % rad    (~5 degrees max lean)
max_omega  = deg2rad(20);   % rad/s 
max_psi    = deg2rad(10);   % rad    (~10 degrees yaw drift)
max_dpsi   = deg2rad(50);   % rad/s
max_x_int = 0.2 %m.s
% Maximum Acceptable Inputs (Accelerations)
max_u_lin  = 2.0;           % m/s^2  (Stepper linear accel limit)
max_u_yaw  = 10.0;          % rad/s^2 (Stepper yaw accel limit)

% State Weighting Matrix (Q)
Q = diag([1/max_x^2, 1/max_v^2, 1/max_theta^2, ...
          1/max_omega^2, 1/max_psi^2, 1/max_dpsi^2,1/max_x_int^2]);

% Input Weighting Matrix (R)
R = diag([1/max_u_lin^2, 1/max_u_yaw^2]);

% Compute Optimal Gain Matrix
K = lqr(A, B, Q, R);
disp('Optimal State-Feedback Gain Matrix (K):');
disp(K);

%% 6. CLOSED-LOOP ANALYSIS
fprintf('\n======================================================\n');
fprintf('                CLOSED-LOOP DYNAMICS\n');
fprintf('======================================================\n');

% Closed-Loop System Matrix
A_cl = A - B*K;

% Poles Check
P_cl = eig(A_cl);
disp('Closed-Loop Poles:'); disp(P_cl);
if all(real(P_cl) < 0)
    fprintf('--> CONCLUSION: System successfully stabilized.\n');
end

% Create Closed-Loop State-Space Object
sys_cl = ss(A_cl, B, C, D);

%% 7. CLOSED-LOOP SIMULATION (Initial Condition Recovery)
% Simulating a physical disturbance: Robot is pushed forward 0.2m, 
% tilted by 5 degrees, and twisted by 10 degrees.
x0 = [-2; 0.0; deg2rad(5); 0.0; deg2rad(10); 0.0;0.0;];
t_sim = linspace(0, 4, 1000); % 4 second simulation

[Y_cl, t_out, X_cl] = initial(sys_cl, x0, t_sim);

% Plot 3: Time-Domain State Recovery
fig3 = figure('Name', 'Closed-Loop State Recovery', 'Position', [200, 200, 900, 700]);

% Subplot A: Linear Motion
subplot(3,1,1);
plot(t_out, X_cl(:,1), 'b', 'LineWidth', 2); hold on;
plot(t_out, X_cl(:,2), 'r--', 'LineWidth', 2);
title('Longitudinal Recovery (Position & Velocity)', 'FontWeight', 'bold');
ylabel('m / (m/s)');
legend('Position (x)', 'Velocity (v)', 'Location', 'northeast');
grid on;

% Subplot B: Pitch Dynamics (The critical balancing act)
subplot(3,1,2);
plot(t_out, rad2deg(X_cl(:,3)), 'g', 'LineWidth', 2); hold on;
plot(t_out, rad2deg(X_cl(:,4)), 'm--', 'LineWidth', 2);
title('Pitch Stabilization', 'FontWeight', 'bold');
ylabel('Degrees / (Deg/s)');
legend('Pitch Angle (\theta)', 'Pitch Rate (\omega)', 'Location', 'northeast');
grid on;

% Subplot C: Yaw Dynamics
subplot(3,1,3);
plot(t_out, rad2deg(X_cl(:,5)), 'k', 'LineWidth', 2); hold on;
plot(t_out, rad2deg(X_cl(:,6)), 'c--', 'LineWidth', 2);
title('Yaw Correction', 'FontWeight', 'bold');
ylabel('Degrees / (Deg/s)');
xlabel('Time (seconds)', 'FontWeight', 'bold');
legend('Yaw Angle (\psi)', 'Yaw Rate', 'Location', 'northeast');
grid on;

%% 8. LOOP TRANSFER RECOVERY & ROBUSTNESS (The LQR Flex)
fprintf('\n======================================================\n');
fprintf('                ROBUSTNESS MARGINS\n');
fprintf('======================================================\n');

% Calculate the Loop Transfer Function: L(s) = K * G(s)
% This creates a 2x2 MIMO loop matrix. We isolate the primary Linear Accel loop (1,1)
sys_L = K * sys_ol; 
sys_loop = sys_L(1,1); 

% Calculate the Closed-Loop SISO function for performance bandwidth
sys_cl_siso = sys_cl(3, 1); % From Linear Accel input (1) to Pitch angle output (3)

% FIGURE 1: Stability Margins (Bode Plot)
figure('Name', 'LQR Loop Margins', 'Position', [100, 100, 800, 600]);
margin(sys_loop); 
grid on;
set(findall(gcf,'type','line'),'linewidth',1.5);
title('1. LQR Stability Margins (Bode Plot)', 'FontSize', 14, 'FontWeight', 'bold');

% FIGURE 2: Nyquist Stability Criterion (The Big Loop)
figure('Name','LQR Nyquist', 'Position', [150, 150, 800, 600]);
nyquist(sys_loop);
grid on;
set(findall(gcf,'type','line'),'linewidth',1.5);
title('2. Compensated Nyquist Stability Criterion', 'FontSize', 14, 'FontWeight', 'bold');
axis([-2 2 -2 2]); % Adjusted to frame the critical -1 point nicely

% FIGURE 3: Performance Analysis (Closed Loop)
figure('Name', 'Closed Loop Performance', 'Position', [200, 200, 800, 600]);
bode(sys_cl_siso);
grid on;
set(findall(gcf,'type','line'),'linewidth',1.5);
title('3. Closed-Loop Pitch Bandwidth', 'FontSize', 14, 'FontWeight', 'bold');